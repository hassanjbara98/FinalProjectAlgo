import pygame
import random
import time
import heapq

from settings import MAP
from settings import WIDTH, CHAR_SIZE, GHOST_SPEED, NAV_HEIGHT, BOARD_WIDTH, BOARD_HEIGHT, TELEPORT_Y
from settings import ALGORITHM_DEFAULT, ALGORITHM_RANDOM, ALGORITHM_ASTAR_1, ALGORITHM_ASTAR_2, ALGORITHM_ASTAR_3

INFINITE_VALUE = 1000000

class Ghost(pygame.sprite.Sprite):
	def __init__(self, row, col, color, algorithm):
		super().__init__()
		self.abs_x = (row * CHAR_SIZE)
		self.abs_y = (col * CHAR_SIZE + NAV_HEIGHT)

		self.algorithm = algorithm

		self.rect = pygame.Rect(self.abs_x, self.abs_y, CHAR_SIZE, CHAR_SIZE)
		self.move_speed = GHOST_SPEED
		self.color = pygame.Color(color)
		self.move_directions = [(-1,0), (0,-1), (1,0), (0,1)]

		self.moving_dir = "up"
		self.img_path = f'assets/ghosts/{color}/'
		self.img_name = f'{self.moving_dir}.png'
		self.image = pygame.image.load(self.img_path + self.img_name)
		self.image = pygame.transform.scale(self.image, (CHAR_SIZE, CHAR_SIZE))
		self.rect = self.image.get_rect(topleft = (self.abs_x, self.abs_y))
		self.mask = pygame.mask.from_surface(self.image)

		self.directions = {'left': (-self.move_speed, 0), 'right': (self.move_speed, 0), 'up': (0, -self.move_speed), 'down': (0, self.move_speed)}
		self.keys = ['left', 'right', 'up', 'down']
		self.direction = (0, 0)

	def move_to_start_pos(self):
		self.rect.x = self.abs_x
		self.rect.y = self.abs_y

	def is_collide(self, x, y, walls_collide_list):
		tmp_rect = self.rect.move(x, y)
		if tmp_rect.collidelist(walls_collide_list) == -1:
			return False
		return True

	def _animate(self):
		self.img_name = f'{self.moving_dir}.png'
		self.image = pygame.image.load(self.img_path + self.img_name)
		self.image = pygame.transform.scale(self.image, (CHAR_SIZE, CHAR_SIZE))
		self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))


	def is_ghost_in_one_cell(self):
		if (self.rect.y - NAV_HEIGHT) % CHAR_SIZE != 0:
			return False
		if self.rect.x % CHAR_SIZE != 0:
			return False
		return True

	def update(self, walls_collide_list, player_y, player_x, obstacle_locations, obstacle_time, predictive_moves, is_game_over):
		# run algorithms
		if self.is_ghost_in_one_cell(): # Note: each ghost may return different values at the same time
			if (self.algorithm == ALGORITHM_RANDOM) or (is_game_over):
				self.random_algorithm(walls_collide_list)
			elif (self.algorithm != ALGORITHM_DEFAULT):
				self.algorithm_astar(player_y, player_x, obstacle_locations, obstacle_time, predictive_moves)

		# move ghost
		if not self.is_collide(*self.direction, walls_collide_list):
			self.rect.move_ip(self.direction)
		else:
			self.direction = (0,0)

		# teleporting to the other side of the map
		if self.rect.right < 0:
			self.rect.x = WIDTH - CHAR_SIZE
		elif self.rect.left >= WIDTH:
			self.rect.x = 0

		self._animate()


	def random_algorithm(self, walls_collide_list):
		# find available moves
		available_moves = []
		for key in self.keys:
			if not self.is_collide(*self.directions[key], walls_collide_list):
				available_moves.append(key)

		if len(available_moves)==0:
			return
		
		randomizing = False if len(available_moves) <= 2 and self.direction != (0,0) else True

		# 60% chance of randomizing ghost move
		if randomizing and random.randrange( 0,100 ) <= 60:
			self.moving_dir = random.choice(available_moves)
			self.direction = self.directions[self.moving_dir]


	def algorithm_astar(self, player_y, player_x, obstacle_locations, obstacle_time_left, predictive_moves):
		# calculate destination
		dest_y = int((player_y - NAV_HEIGHT + CHAR_SIZE/2) // CHAR_SIZE)
		dest_x = int((player_x + CHAR_SIZE/2) // CHAR_SIZE)
		if (dest_x < -0):
			dest_x = BOARD_WIDTH-1
		elif (dest_x >= BOARD_WIDTH):
			dest_x = 0

		# calculate start
		start_y = (self.rect.y - NAV_HEIGHT) // CHAR_SIZE
		start_x = self.rect.x // CHAR_SIZE
		if (start_x < -0):
			start_x = BOARD_WIDTH-1
		elif (start_x >= BOARD_WIDTH):
			start_x = 0

		# reached destination already
		if (start_y == dest_y) and (start_x == dest_x):
			self.direction = (0, 0)
			return

		open_set = [(0, start_y, start_x)]
		time_distances = [[INFINITE_VALUE]*BOARD_WIDTH for i in range(BOARD_HEIGHT)] # distance from start
		came_from = [[(-1,-1)] * BOARD_WIDTH for i in range(BOARD_HEIGHT)]
		time_distances[start_y][start_x] = 0


		# Inner function: commonly used heuristic for maze-solving: Manhattan distance - support teleport
		def astar_heuristic(fromy, fromx, toy, tox):
			manhattan = abs(fromy - toy) + abs(fromx - tox)
			manhattan_teleport1 = abs(fromy - TELEPORT_Y) + abs(fromx) + abs(toy - TELEPORT_Y) + abs(tox - BOARD_WIDTH + 1)
			manhattan_teleport2 = abs(fromy - TELEPORT_Y) + abs(fromx - BOARD_WIDTH + 1) + abs(toy - TELEPORT_Y) + abs(tox)
			return min(manhattan, manhattan_teleport1, manhattan_teleport2)
		

		# Inner function: Trace back to find moving direction for ghost
		def trace_direction():
			nonlocal self
			nonlocal start_y
			nonlocal start_x
			nonlocal dest_y
			nonlocal dest_x
			nonlocal came_from

			# trace back
			while (came_from[dest_y][dest_x] != (start_y, start_x)):
				dest_y, dest_x = came_from[dest_y][dest_x]

			# translate direction
			if dest_y < start_y:
				self.direction = self.directions['up']
			elif dest_y > start_y:
				self.direction = self.directions['down']
			elif (dest_x == start_x - 1) or ((dest_x == BOARD_WIDTH - 1) and (start_x == 0)):
				self.direction = self.directions['left']
			else:
				self.direction = self.directions['right']


		# algorithm_astar continues here
		while len(open_set) > 0:
			# pop the shortest distance
			cur_priority, cur_y, cur_x = heapq.heappop(open_set) # cur_priority just used to sort, not use it anywhere
			if (cur_y == dest_y) and (cur_x == dest_x):
				trace_direction() # destination reached
				return

			# find all neighbors
			neighbor = [(cur_y-1,cur_x),(cur_y+1,cur_x)]
			if (cur_x==0):
				neighbor = neighbor + [(cur_y, BOARD_WIDTH-1)]
			else:
				neighbor = neighbor + [(cur_y, cur_x-1)]
			if (cur_x==BOARD_WIDTH-1):
				neighbor = neighbor + [(cur_y, 0)]
			else:
				neighbor = neighbor + [(cur_y, cur_x+1)]

			# check routes to each neighbor
			for (next_y,next_x) in neighbor:
				if MAP[next_y][next_x]=="1":
					continue # wall
				astar_distance = 1

				if (self.algorithm == ALGORITHM_ASTAR_3):
					if (next_y, next_x) in predictive_moves:
						if (cur_y, cur_x) in predictive_moves:
							astar_distance = 0.1
				if (self.algorithm == ALGORITHM_ASTAR_2) or (self.algorithm == ALGORITHM_ASTAR_3):
					if (next_y, next_x) in obstacle_locations:
						astar_distance = astar_distance + obstacle_time_left

				next_distance = time_distances[cur_y][cur_x] + astar_distance
				if next_distance < time_distances[next_y][next_x]: # find a new (or shorter) route
					time_distances[next_y][next_x] = next_distance
					came_from[next_y][next_x] = (cur_y, cur_x)
					next_priority = next_distance + astar_heuristic(next_y, next_x, dest_y, dest_x)
					heapq.heappush(open_set, (next_priority, next_y, next_x))

		# debug only - if there is no error, this case will never happen
		print("ERROR: no path - this case should not happen!")

