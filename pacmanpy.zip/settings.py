MAP = [
    ['1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1'],
	['1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1'],
	['1',' ','1','1',' ','1','1','1',' ','1',' ','1','1','1',' ','1','1',' ','1'],
	['1',' ',' ',' ',' ','1',' ',' ',' ','1',' ',' ',' ','1',' ',' ',' ',' ','1'],
	['1','1',' ','1',' ','1',' ','1',' ','1',' ','1',' ','1',' ','1',' ','1','1'],
	['1',' ',' ','1',' ',' ',' ','1',' ',' ',' ','1',' ',' ',' ','1',' ',' ','1'],
	['1',' ','1','1','1','1',' ','1','1','1','1','1',' ','1','1','1','1',' ','1'],
	['1',' ',' ',' ',' ',' ',' ',' ',' ','r',' ',' ',' ',' ',' ',' ',' ',' ','1'],
	['1','1',' ','1','1','1',' ','1','1','-','1','1',' ','1','1','1',' ','1','1'],
	['-',' ',' ',' ',' ','1',' ','1','s','p','o','1',' ','1',' ',' ',' ',' ','-'], # character - to disable random obstacle at teleports
	['1','1',' ','1',' ','1',' ','1','1','1','1','1',' ','1',' ','1',' ','1','1'],
	['1',' ',' ','1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1',' ',' ','1'],
	['1',' ','1','1','1','1',' ','1','1','1','1','1',' ','1','1','1','1',' ','1'],
	['1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1'],
	['1','1','1',' ','1','1','1',' ','1','1','1',' ','1','1','1',' ','1','1','1'],
	['1',' ',' ',' ','1',' ',' ',' ',' ','P',' ',' ',' ',' ','1',' ',' ',' ','1'],
	['1',' ','1',' ','1',' ','1',' ','1','1','1',' ','1',' ','1',' ','1',' ','1'],
	['1',' ','1',' ',' ',' ','1',' ',' ',' ',' ',' ','1',' ',' ',' ','1',' ','1'],
	['1',' ','1','1','1',' ','1','1','1',' ','1','1','1',' ','1','1','1',' ','1'],
	['1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1'],
	['1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1']
]

BOARD_WIDTH = 19
BOARD_HEIGHT = 21
TELEPORT_Y = 9

BOARD_RATIO = (len(MAP[0]), len(MAP))
CHAR_SIZE = 30

WIDTH, HEIGHT = (BOARD_RATIO[0] * CHAR_SIZE, BOARD_RATIO[1] * CHAR_SIZE)
NAV_HEIGHT = 60

PLAYER_LIFE = 1

# IMPORTANT NOTICE: CHAR_SIZE % PLAYER_SPEED == 0 and CHAR_SIZE % GHOST_SPEED == 0
PLAYER_SPEED = CHAR_SIZE // 5 # PAC-MAN travel distance in 1 second = PLAYER_SPEED * FRAMES_PER_SECOND = CHAR_SIZE * 4
GHOST_SPEED = CHAR_SIZE // 6 # Ghost travel distance in 1 second = GHOST_SPEED * FRAMES_PER_SECOND = CHAR_SIZE * 3.33333333
FRAMES_PER_SECOND = 20

GHOST_PASS_A_CHAR_TIME = 333 # time a ghost takes to pass through a CHAR in game board
TIME_OF_A_STEP = 2000 # Recommend: (TIME_OF_A_STEP == GHOST_PASS_A_CHAR_TIME) or (TIME_OF_A_STEP % GHOST_PASS_A_CHAR_TIME == 0)

RANDOM_OBSTACLES = 3
OBSTACLES_SPAWN_TIME = 5
OBSTACLES_LIFE_TIME = 3

ALGORITHM_DEFAULT = 0 # no move at all
ALGORITHM_RANDOM = 1 # random move
ALGORITHM_ASTAR_1 = 2 # A* algorithm (does not : obstacles & PacMan direction)
ALGORITHM_ASTAR_2 = 3 # A* algorithm (check: obstacles & no-check: PacMan direction)
ALGORITHM_ASTAR_3 = 4


