import pygame
import time
import random

from settings import HEIGHT, WIDTH, NAV_HEIGHT, CHAR_SIZE, MAP, BOARD_WIDTH, BOARD_HEIGHT, TELEPORT_Y
from settings import PLAYER_SPEED, PLAYER_LIFE, RANDOM_OBSTACLES, TIME_OF_A_STEP, GHOST_PASS_A_CHAR_TIME
from settings import  ALGORITHM_DEFAULT, ALGORITHM_RANDOM, ALGORITHM_ASTAR_1, ALGORITHM_ASTAR_2, ALGORITHM_ASTAR_3

from pac import Pac
from cell import Cell
from berry import Berry
from ghost import Ghost
from display import Display
from obstacle import Obstacle

class World:
	def __init__(self, screen):
		self.screen = screen

		self.player = pygame.sprite.GroupSingle()
		self.ghosts = pygame.sprite.Group()
		self.walls = pygame.sprite.Group()
		self.berries = pygame.sprite.Group()
		self.obstacles = pygame.sprite.Group()

		self.display = Display(self.screen)

		self.game_over = False
		self.reset_pos = False
		self.player_score = 0
		self.game_level = 1

		self.obstacle_locations = []
		self.obstacle_time_left = 0
		self.predictive_moves = []

		self._generate_world()
		self.game_start_time = pygame.time.get_ticks()


	# create and add player to the screen
	def _generate_world(self):
		self.movingobjects_collide_list = []

		# renders obstacle from the MAP table
		for y_index, col in enumerate(MAP):
			for x_index, char in enumerate(col):
				if char == "1":	# for walls
					self.walls.add(Cell(x_index, y_index, CHAR_SIZE, CHAR_SIZE))
				elif char == " ":	 # for paths to be filled with berries
					self.berries.add(Berry(x_index, y_index, CHAR_SIZE // 4))
				#for Ghosts's starting position
				elif char == "s":
					self.ghosts.add(Ghost(x_index, y_index, "skyblue", ALGORITHM_RANDOM))
				elif char == "p": 
					self.ghosts.add(Ghost(x_index, y_index, "pink", ALGORITHM_ASTAR_1))
				elif char == "o":
					self.ghosts.add(Ghost(x_index, y_index, "orange", ALGORITHM_ASTAR_2))
				elif char == "r":
					self.ghosts.add(Ghost(x_index, y_index, "red", ALGORITHM_ASTAR_3))
				elif char == "P":	# for PacMan's starting position 
					self.player.add(Pac(x_index, y_index))

		# generate more walls to block change direction at teleport - create collide list 
		self.walls.add(Cell(-1, TELEPORT_Y-1, CHAR_SIZE, CHAR_SIZE))
		self.walls.add(Cell(-1, TELEPORT_Y+1, CHAR_SIZE, CHAR_SIZE))
		self.walls.add(Cell(BOARD_WIDTH, TELEPORT_Y-1, CHAR_SIZE, CHAR_SIZE))
		self.walls.add(Cell(BOARD_WIDTH, TELEPORT_Y+1, CHAR_SIZE, CHAR_SIZE))
		self.walls_collide_list = [wall.rect for wall in self.walls.sprites()]
		self.walls_collide_list_size = len(self.walls_collide_list)


	def generate_obstacles(self):
		# get collide list of ghosts and player
		dynamic_objects_collide_list = [object.rect for object in self.ghosts.sprites()]
		dynamic_objects_collide_list = dynamic_objects_collide_list + [object.rect for object in self.player.sprites()]

		# generate random obstacles
		while (len(self.obstacles) < RANDOM_OBSTACLES):
			obstacle_y = random.randint(0, len(MAP)-1)
			obstacle_x = random.randint(0, len(MAP[obstacle_y])-1)
			if (MAP[obstacle_y][obstacle_x] != " "): # do not generate on walls and start positions of ghosts and player
				continue
			tmp_obstacle = Obstacle(obstacle_x, obstacle_y, CHAR_SIZE, CHAR_SIZE)
			tmp_rect = tmp_obstacle.rect
			if tmp_rect.collidelist(dynamic_objects_collide_list) != -1: # do not generate obstalces that collide with other obstalces, ghosts and player
				continue
			dynamic_objects_collide_list.append(tmp_rect)
			self.obstacles.add(tmp_obstacle)
			self.obstacle_locations.append((obstacle_y, obstacle_x))

		# temporary add obstalces to walls list to prevent ghosts and player pass through obstacles
		for obstacle in self.obstacles.sprites():
			self.walls_collide_list.append(obstacle.rect)
		

	def remove_obstacles(self):
		while (len(self.walls_collide_list)>self.walls_collide_list_size):
			self.walls_collide_list.pop()
		for obstacle in self.obstacles.sprites():
			obstacle.kill()
		self.obstacle_locations = []

	
	def manage_obstacles(self):
		time_passed = pygame.time.get_ticks() - self.game_start_time
		if (time_passed < 1000):
			self.obstacle_time_left = 0
			return
		time_passed = time_passed - 1000 # not generate obstacles in first 1s (1000ms)
		time_passed = time_passed % (TIME_OF_A_STEP * 5)
		if (time_passed < TIME_OF_A_STEP * 3):
			if len(self.obstacles.sprites())==0:
				self.generate_obstacles()
			self.obstacle_time_left = (TIME_OF_A_STEP * 3 - time_passed) / GHOST_PASS_A_CHAR_TIME
			return
		self.obstacle_time_left = 0
		if len(self.obstacles.sprites())!=0:
			self.remove_obstacles()


	def build_predictive_moves(self):
		# calculate Pac-Man position
		pacman_y = int((self.player.sprites()[0].rect.y - NAV_HEIGHT + CHAR_SIZE/2) // CHAR_SIZE)
		pacman_x = int((self.player.sprites()[0].rect.x + CHAR_SIZE/2) // CHAR_SIZE)
		if (pacman_x < 0):
			pacman_x = BOARD_WIDTH-1
		elif (pacman_x >= BOARD_WIDTH):
			pacman_x = 0

		#build predictive moves
		self.predictive_moves = [(pacman_y, pacman_x)]
		delta_x, delta_y = self.player.sprites()[0].direction
		while True:
			if delta_x < 0:
				pacman_x = pacman_x - 1
			elif delta_x > 0:
				pacman_x = pacman_x + 1
			elif delta_y < 0:
				pacman_y = pacman_y - 1
			else:
				pacman_y = pacman_y + 1
			if (pacman_x < 0):
				pacman_x = BOARD_WIDTH-1
			elif (pacman_x >= BOARD_WIDTH):
				pacman_x = 0
			if (MAP[pacman_y][pacman_x]=="1"): # always happen in this loop
				return
			self.predictive_moves.append((pacman_y, pacman_x))


	def generate_new_level(self):
		for y_index, col in enumerate(MAP):
			for x_index, char in enumerate(col):
				if char == " ":	 # for paths to be filled with berries
					self.berries.add(Berry(x_index, y_index, CHAR_SIZE // 4))
		time.sleep(1)
		self.game_start_time = pygame.time.get_ticks()


	def restart_level(self):
		self.berries.empty()
		[ghost.move_to_start_pos() for ghost in self.ghosts.sprites()]
		self.game_level = 1
		self.player.sprite.pac_score = 0
		self.player.sprite.life = PLAYER_LIFE
		self.player.sprite.move_to_start_pos()
		self.player.sprite.direction = (0, 0)
		self.player.sprite.status = "idle"
		self.remove_obstacles()
		self.generate_obstacles()
		self.obstacle_locations = []
		self.obstacle_time_left = 0
		self.predictive_moves = []
		self.generate_new_level()


	# displays nav
	def _dashboard(self):
		self.display.show_life(self.player.sprite.life)
		self.display.show_level(self.game_level)
		self.display.show_score(self.player.sprite.pac_score)


	def _check_game_state(self):
		# checks if game over
		if self.player.sprite.life == 0:
			self.game_over = True

		# generates new level
		if len(self.berries) == 0 and self.player.sprite.life > 0:
			self.game_level += 1
			for ghost in self.ghosts.sprites():
				ghost.move_speed += self.game_level
				ghost.move_to_start_pos()

			self.player.sprite.move_to_start_pos()
			self.player.sprite.direction = (0, 0)
			self.player.sprite.status = "idle"
			self.generate_new_level()


	def update(self):
		if not self.game_over:
			# obstacles manager
			self.manage_obstacles()

			# player movement
			pressed_key = pygame.key.get_pressed()
			self.player.sprite.animate(pressed_key, self.walls_collide_list)

			# teleporting to the other side of the map
			if self.player.sprite.rect.right < 0:
				self.player.sprite.rect.x = WIDTH - CHAR_SIZE
			elif self.player.sprite.rect.left >= WIDTH:
				self.player.sprite.rect.x = 0

			# PacMan eating-berry effect
			for berry in self.berries.sprites():
				if self.player.sprite.rect.colliderect(berry.rect):
					self.player.sprite.pac_score += 10
					berry.kill()

			# PacMan bumping into ghosts
			for ghost in self.ghosts.sprites():
				if self.player.sprite.rect.colliderect(ghost.rect):
					time.sleep(1)
					self.player.sprite.life -= 1
					self.reset_pos = True
					break

		self._check_game_state()

		# build list of predictive moves 
		self.build_predictive_moves()

		# rendering
		[wall.update(self.screen) for wall in self.walls.sprites()]
		[berry.update(self.screen) for berry in self.berries.sprites()]
		[obstacle.update(self.screen) for obstacle in self.obstacles.sprites()]
		[ghost.update(self.walls_collide_list, self.player.sprites()[0].rect.y, self.player.sprites()[0].rect.x, self.obstacle_locations, self.obstacle_time_left, self.predictive_moves, self.game_over) for ghost in self.ghosts.sprites()]
		[obstalce.update(self.screen) for obstalce in self.obstacles.sprites()]
		self.ghosts.draw(self.screen)

		self.player.update()
		self.player.draw(self.screen)
		self.display.game_over() if self.game_over else None

		self._dashboard()

		# reset Pac and Ghosts position after PacMan get captured
		if self.reset_pos and not self.game_over:
			[ghost.move_to_start_pos() for ghost in self.ghosts.sprites()]
			self.player.sprite.move_to_start_pos()
			self.player.sprite.status = "idle"
			self.player.sprite.direction = (0,0)
			self.reset_pos = False

		# for restart button
		if self.game_over:
			pressed_key = pygame.key.get_pressed()
			if pressed_key[pygame.K_SPACE]:
				self.game_over = False
				self.restart_level()