import pygame

from settings import WIDTH, HEIGHT, CHAR_SIZE, NAV_HEIGHT

pygame.font.init()

class Display:
	def __init__(self, screen):
		self.screen = screen
		self.font = pygame.font.SysFont("arial", CHAR_SIZE)
		self.game_over_font = pygame.font.SysFont("arial", 48)
		self.text_color = pygame.Color("white")
				
	def show_life(self, life):
		img_path = "assets/life/life.png"
		life_image = pygame.image.load(img_path)
		life_image = pygame.transform.scale(life_image, (CHAR_SIZE, CHAR_SIZE))
		life_x = WIDTH - CHAR_SIZE * 1.5

		if life != 0:
			for life in range(life):
				self.screen.blit(life_image, (life_x, CHAR_SIZE // 2))
				life_x -= CHAR_SIZE

	def show_level(self, level):
		level_x = WIDTH // 2 - CHAR_SIZE * 2
		level = self.font.render(f'Level {level}', True, self.text_color)
		self.screen.blit(level, (level_x, CHAR_SIZE // 2))

	def show_score(self, score):
		score_x = CHAR_SIZE // 2
		score = self.font.render(f'{score}', True, self.text_color)
		self.screen.blit(score, (score_x, CHAR_SIZE // 2))

	# add game over message
	def game_over(self):
		message = self.game_over_font.render(f'GAME OVER', True, pygame.Color("yellow"))
		instruction = self.font.render(f'Press SPACE BAR to restart!', True, pygame.Color("aqua"))
		self.screen.blit(message, (WIDTH // 4 + 0.0 * CHAR_SIZE , HEIGHT // 2 + NAV_HEIGHT - 2 * CHAR_SIZE))
		self.screen.blit(instruction, (WIDTH // 4 - 1.7 * CHAR_SIZE, HEIGHT // 2 + NAV_HEIGHT))